%%%% Script for Sample Size Determination
disp(sprintf('Sample Size Determination'));

% Ask for degrees of freedom (dof)
dof = input('Degrees of Freedom - (|X|-1): ');
% Ask for significance level (alpha)
alpha = input('Significance of the test - alpha value: ');
% Ask for power of the test
power = input('Desired power of the test: ');
% Ask for the effect we want to observe, this scripti will produce will
% generate graphs similar with the Figure 2,3 of the paper but
% furthermore will point out the minimum sample size for the desired effect
desiredEffect = input('Desired effect to be observed (in nats) -  0.001 < I(X;Y) < 0.2 : ');
% Ask for prevelance, the belief over the probability of example being
% positive, p(y=1)
prevalence = input('Prevalence of positive examples - p(y^+): ');
% Ask for the amount of supervision c = p(s=1|y=1)
supervision = input('Probability of an example being labelled - p(s^+): ');

% minfo contains the effects that we will use in our power analysis
minfo = [0.001 0.01:0.01:0.2];
minfo = sort(unique([minfo desiredEffect])); 
% Initalise the minimum samples to be zero for each desired effect size
minumumSampleSize = zeros(1,length(minfo));
% Calculate the critical value of the test
critical_value = chi2inv(1-alpha,dof);

% Calculate the probability of an example being labeled p(s=1)
pSequal1 = supervision;
% Calculate the correction factor kappa 
Factor = ((1-prevalence)/prevalence ) * (pSequal1/(1-pSequal1)) ;

% For each effect size calculate the minimum sample size
for minfoIndex = 1:length(minfo)
disp(sprintf('%d out of %d',minfoIndex,length(minfo))) 
% Estimate the power with zero sample size
estimated_power = 1-ncx2cdf(critical_value,dof,2*minumumSampleSize(minfoIndex)*Factor*minfo(minfoIndex));
% Check the difference between the desired power and the Estimated power
% and if desired power > estimated power, increase the sample size by one and
% re-calculate the power, else you found the minimum sample size to observe
% the given effect with the desired power.
while power-estimated_power > 0
    minumumSampleSize(minfoIndex) = minumumSampleSize(minfoIndex)+1;
    estimated_power = 1-ncx2cdf(critical_value,dof,2*minumumSampleSize(minfoIndex)*Factor*minfo(minfoIndex));
end

end

figure
hold on
grid on
plot(minfo', minumumSampleSize','LineWidth',3);
ylabel('N','FontSize',14);
xlabel('I(X;Y)','FontSize',14);
xlim([minfo(1) minfo(end)])
ylim([minumumSampleSize(end) minumumSampleSize(1)]);
title(sprintf('\\alpha = %0.2f, power = %0.2f, df = %d, p(y^+) = %0.2f, p(s^+) = %0.2f',alpha,power,dof,prevalence, supervision),'FontSize',14)
plot([desiredEffect desiredEffect],[minumumSampleSize(end) minumumSampleSize(find(floor(1000*minfo) == floor(1000*desiredEffect)))],'r-.','LineWidth',3)
plot([desiredEffect minfo(1)],[minumumSampleSize(find(floor(1000*minfo) == floor(1000*desiredEffect))) minumumSampleSize(find(floor(1000*minfo) == floor(1000*desiredEffect)))],'r-.','LineWidth',3)
hold off



