%%%% Script for Supervision Determination
disp(sprintf('Supervision Determination - Determine the ratio of labelled positive examples'));

% Ask for degrees of freedom (dof)
dof = input('Degrees of Freedom - (|X|-1): ');
% Ask for significance level (alpha)
alpha = input('Significance of the test - alpha value: ');
% Ask for power of the test
power = input('Desired power of the test: ');
% Ask for the effect we want to observe, this scripti will produce will
% generate graphs similar with the Figure 2,3 of the paper but
% furthermore will point out the minimum sample size for the desired effect
desiredEffect = input('Desired effect to be observed (in nats)  - 0.001 < I(X;Y) < 0.2 : ');
% Ask for prevelance, the belief over the probability of example being
% positive, p(y=1)
prevalence = input('Prevalence of positive examples - p(y^+): ');
% Ask for the sample size
samplesize = input('Sample Size - N: ');

% minfo contains the effects that we will use in our power analysis
minfo = [0.001 0.01:0.01:0.2];
minfo = sort(unique([minfo desiredEffect])); 
% Initalise the minimum amount of ssupervision to be zero for any desired
% effect
minumumSupervisedExamples = zeros(1,length(minfo));
% Calculate the critical value of the test
critical_value = chi2inv(1-alpha,dof);


% For each effect size calculate the minimum amount of supervision
for minfoIndex = 1:length(minfo)
    disp(sprintf('%d out of %d',minfoIndex,length(minfo)))
    % Calculate the probability of an example being labeled p(s=1)
    pSequal1 = minumumSupervisedExamples(minfoIndex)/samplesize;
    % Calculate the correction factor kappa
    Factor = ((1-prevalence)/prevalence ) * (pSequal1/(1-pSequal1)) ;
    % Estimate the power with zero supervision
    estimated_power = 1-ncx2cdf(critical_value,dof,2*samplesize*Factor*minfo(minfoIndex));
    % Check the difference between the desired power and the Estimated power
    % and if desired power > estimated power, increase the supervision by 0.001 and
    % re-calcuate the power (in order to do so we should re-calculate the correction
    % factor), else you found the minimum amount of supervision to observe
    % the given effect with the desired power.
    while power-estimated_power > 0
        minumumSupervisedExamples(minfoIndex) = minumumSupervisedExamples(minfoIndex)+1;
        pSequal1 = minumumSupervisedExamples(minfoIndex)/samplesize;
        Factor = ((1-prevalence)/prevalence ) * (pSequal1/(1-pSequal1)) ;
        estimated_power = 1-ncx2cdf(critical_value,dof,2*samplesize*Factor*minfo(minfoIndex));
        
        if minumumSupervisedExamples(minfoIndex) > prevalence*samplesize 
            minumumSupervisedExamples(minfoIndex) = samplesize;
            break;
        end
    end
    
    
    
    
end

figure
hold on
grid on
plot(minfo', minumumSupervisedExamples','LineWidth',3);
ylabel('N_{S^+}','FontSize',14);
xlabel('I(X;Y)','FontSize',14);
xlim([minfo(1) minfo(end)])
ylim([minumumSupervisedExamples(end) min(minumumSupervisedExamples(1),prevalence*samplesize)]);
title(sprintf('\\alpha = %0.2f, power = %0.2f, df = %d, p(y^+) = %0.2f, N = %d',alpha,power,dof,prevalence, samplesize),'FontSize',14)
plot([desiredEffect desiredEffect],[minumumSupervisedExamples(end) minumumSupervisedExamples(find(floor(1000*minfo) == floor(1000*desiredEffect)))],'r-.','LineWidth',3)
plot([desiredEffect minfo(1)],[minumumSupervisedExamples(find(floor(1000*minfo) == floor(1000*desiredEffect))) minumumSupervisedExamples(find(floor(1000*minfo) == floor(1000*desiredEffect)))],'r-.','LineWidth',3)
hold off



