package ucs;

import java.util.ArrayList;
import java.util.Iterator;

import dataprocessing.*;

/**
 * Main UCS class. Make an instance of this (providing a <b>UCSconfig</b> object)
 * and call <i>run(int)</i> or <i>run(int, int)</i> to use UCS on your data.
 * <b>Note: this implementation (version 0.1b) can handle only DISCRETE inputs (any arity), and only TWO CLASS problems.</b>
 * 
 * @author Gavin Brown
 */
public class UCS {

	////////////////////////////////////////////////////////////////////////////////////////////
	////////////////////////////////////////////////////////////////////////////////////////////
	////////////////////////////////////////////////////////////////////////////////////////////

	/** Flag indicating whether UCS is in testing mode at the moment or not. */
	protected static boolean TESTMODE = false;
	
	/** Counter indicating the current number of iterations (aka generations) processed by this UCS object. */
	protected static int currentIteration=0;

	protected ArrayList traindata = null, testdata = null;
	protected ArrayList lastFewExamples = null;
	protected double aucAccuracy=0;
	
	protected ArrayList matchSet = new ArrayList();
	protected ArrayList correctSet = new ArrayList();

	////////////////////////////////////////////////////////////////	
	////////////////////////////////////////////////////////////////	
	////////////////////////////////////////////////////////////////
	
	/** The population in this instance of UCS */
	public Population pop = new Population();
	
	/** The configuration for this instance of UCS */
	public UCSconfig params = null;
	
	////////////////////////////////////////////////////////////////	
	////////////////////////////////////////////////////////////////	
	////////////////////////////////////////////////////////////////	

	/**
	 * Constructor for the main UCS class.
	 * @param p A UCSparams object specifying how this instance of UCS should function.
	 */
	public UCS( UCSconfig p )
	{		
		this.params = (UCSconfig)p.clone();
		
		if (this.params.trainingFile==null)
		{
			System.out.println("No problem data specified.");
			System.exit(1);
		}
		else loadData(this.params.trainingFile);
	}
		
	////////////////////////////////////////////////////////////////////////////////////////////
	////////////////////////////////////////////////////////////////////////////////////////////
	////////////////////////////////////////////////////////////////////////////////////////////
	
	/**
	 * Set the problem data for this UCS instance.
	 * @param filename The datafile to use.
	 */
	protected void loadData( String filename )
	{
		//READ THE DATAFILE
		//
		DataSource reader = new DataSource(filename);
		DataSource testReader = null;
		reader.shuffle();
		
		//make a blank RuleCondition so it initializes its necessary variables from the datafile.
		RuleCondition x = new RuleCondition( reader.numInputs );
		
		if (params.onlinelearning)
		{
			traindata = reader.getData();
			testdata = traindata;
		}
		else
		{
			if(params.testingFile==null)
			{
				//no test data specified so presume a 50:50 random split
				traindata = reader.getTrainingData();
				reader.addTargetNoise(params.noise, traindata);
				testdata = reader.getTestingData();
			}
			else
			{
				//load the specified testing data
				traindata = reader.getData();
				testReader = new DataSource(params.testingFile);
				testdata = testReader.getData();
				
				//note: i'm not sure what would happen if there were missing values
				//in either the training or testing data
			}
		}
	
	}
	
	////////////////////////////////////////////////////////////////////////////////////////////
	////////////////////////////////////////////////////////////////////////////////////////////
	////////////////////////////////////////////////////////////////////////////////////////////
	
	/**
	 *  Main method to be run.
	 *  @param maxiterations The number of iterations to execute.
	 */
	public void run( int maxiterations ) { run(maxiterations, 100); }

	/**
	 *  Main method to be run.
	 *  @param maxiterations The number of iterations to execute.
	 *  @param STEP The regular number of iterations when output information is printed.
	 */
	public void run( int maxiterations, int STEP )
	{	
		lastFewExamples = new ArrayList();

		//START THE ITERATIONS LOOP
		int stoppoint=currentIteration+maxiterations;
		for (; currentIteration<=stoppoint; currentIteration++)
		{
			if(currentIteration%STEP==0) test();
			if(currentIteration%50==0) lastFewExamples = new ArrayList();
			
			//PICK A RANDOM DATA ITEM
			//
			int randomIndex = UCSconfig.generator.nextInt(traindata.size());
			Example e = (Example)traindata.get(randomIndex);
			
			//STORE IT SO WE CAN CALCULATE ACCURACY OVER LAST FIFTY EXAMPLES
			//
			lastFewExamples.add(e);
			
			//IDENTIFY THE MATCH SET AND THE CORRECT SET
			//
			getMatchAndCorrectSets(e);

			//CHECK THE CORRECT SET
			//
			int correctSetSize = correctSet.size();
			int averageLastTimeInTheGA=0;
			if (correctSetSize==0)
			{
				//DO COVERING IF NECESSARY
				//
				covering(e);
			}
			else
			{
				//UPDATE THE AVERAGE CORRECT SET SIZES
				// - TO BE USED LATER IN DELETION PROBABILITIES
				//
				for(int i=0; i<correctSetSize; i++)
				{
					Indiv ind = (Indiv)correctSet.get(i);
					ind.updateCorrectSetSize(correctSetSize);
					averageLastTimeInTheGA += ind.lastTimeThisWasInTheGA;
				}
			}
			
			//GET THE AVERAGE TIMESTAMP
			//
			averageLastTimeInTheGA /= (double)correctSetSize;
			int gaRecency = currentIteration - averageLastTimeInTheGA;
			
			//INVOKE THE GA MAYBE
			//
			if(		gaRecency > params.gaThreshold
				&& 	currentIteration > params.gaThreshold
				&&	correctSetSize>0)
			{
					invokeGA();
			}
	
			
		}//END ITERATIONS LOOP


		System.out.println("Done "+maxiterations+" iterations.");
				
	}//END MAIN
	

	////////////////////////////////////////////////////////////////////////////////////////////
	////////////////////////////////////////////////////////////////////////////////////////////
	////////////////////////////////////////////////////////////////////////////////////////////
	

	protected void test()
	{
		ucs.UCS.TESTMODE=true;
		double systemCorrect=0;
		double averageMatchSetSize=0, averageCorrectSetSize=0;
		
		//HOW ARE WE DOING TESTING?
		int numTesting;
		Iterator testDataIterator = null;
		if(params.onlinelearning)
		{
			//TEST ON LAST 50 EXAMPLES
			numTesting = lastFewExamples.size();
			testDataIterator = lastFewExamples.iterator();
		}
		else
		{
			//TEST ON THE TESTING DATA
			numTesting = testdata.size();
			testDataIterator = testdata.iterator();
		}
		
		int zeros=0;
		while (testDataIterator.hasNext())
		{
			//GET THE NEXT TESTING EXAMPLE
			//
			Example e = (Example)testDataIterator.next();
			
			//GET THE MATCH AND CORRECT SETS FOR THIS EXAMPLE
			//
			getMatchAndCorrectSets(e);
			
			//UPDATE SOME STATISTICS
			//
			averageMatchSetSize += matchSet.size();
			averageCorrectSetSize += correctSet.size();
			
			//FORM THE SYSTEM PREDICTION
			//
			//int guess = systemPrediction();
			int guess = params.systemPredictor.predict( matchSet );
			
			//CHECK IT
			//
			if(guess==e.target) systemCorrect++;
		}
		
		
		//FINALISE THE STATISTICS
		//
		averageMatchSetSize /= numTesting;
		averageCorrectSetSize /= numTesting;
		systemCorrect /= numTesting;
		double percentageCorrectInMatchSet = (averageCorrectSetSize/averageMatchSetSize);
		if(Double.isNaN(percentageCorrectInMatchSet)) percentageCorrectInMatchSet=0;
		if (Double.isNaN(systemCorrect)) systemCorrect=0;
		
		int macroclassifiers = pop.numMacroClassifiers();
		
		aucAccuracy+=systemCorrect;

		int onlinelearn=0; if (params.onlinelearning) onlinelearn=1;
		
		//PRINT THEM ALL OUT
		//
		System.out.println("RESULTS iteration "+currentIteration+
				" accuracy "+systemCorrect+
				" v "+params.v+
				//" popsize "+this.pop.size()+
				//" matchsetsize "+averageMatchSetSize+
				//" cs "+percentageCorrectInMatchSet+
				" macro "+macroclassifiers+
				" aucacc "+aucAccuracy+
				" online "+onlinelearn
				//" numTesting "+numTesting
		);
		
		ucs.UCS.TESTMODE=false;
	}
	
	////////////////////////////////////////////////////////////////////////////////////////////
	////////////////////////////////////////////////////////////////////////////////////////////
	////////////////////////////////////////////////////////////////////////////////////////////
	/////////////////////////////////////////////////////////////////////////////
	
	protected void covering( Example e )
	{
		//MAKE AN INDIVIDUAL THAT MATCHES THIS INPUT
		Indiv ind = new Indiv( e.inputs.length, this.params );
		ind.condition.set( e.inputs );
		
		//FLIP SOME BITS TO A DON'T CARE SYMBOL
		for (int i=0; i<ind.condition.values.length; i++)
		{
			//FLIP WITH PROBABILITY p
			if(params.generator.nextDouble() < params.coveringProbability)
			{
				ind.condition.values[i] = RuleCondition.HASH;
			}
		}

		//copy details
		ind.action = e.target;
		ind.numMatches = 1;
		ind.numCorrect = 1;
		ind.correctSetSize = 1;
		ind.numerosity = 1;
		ind.accuracy = 1;
		

		//add it
		//
		pop.add( ind );
		
		//delete if necessary
		deleteIfNecessary();
	}
	
	////////////////////////////////////////////////////////////////////////////////////////////
	////////////////////////////////////////////////////////////////////////////////////////////
	////////////////////////////////////////////////////////////////////////////////////////////

	protected void getMatchAndCorrectSets( Example e )
	{
		//BLANK THE PREVIOUS SETS
		matchSet = new ArrayList();
		correctSet = new ArrayList();

		//IDENTIFY THE MATCH AND CORRECT SETS
		Iterator popIterator = pop.iterator();
		while (popIterator.hasNext())
		{
			Indiv ind = (Indiv)popIterator.next();
			
			if(ind.matches(e.inputs))
			{
				matchSet.add(ind);
				if( ind.test(e.target) )	correctSet.add(ind);
			}
		}
				
	}

	////////////////////////////////////////////////////////////////////////////////////////////
	////////////////////////////////////////////////////////////////////////////////////////////
	////////////////////////////////////////////////////////////////////////////////////////////

	protected void deleteIfNecessary()
	{
		//DELETION SCHEME AS SPECIFIED IN THEIR PAPERS
		//
		while(pop.size() > params.POPMAXSIZE)
		{
			Iterator popit = pop.iterator();
			int sum=0;
			double averageFitness=0;
			while (popit.hasNext())
			{
				Indiv ind = ((Indiv)popit.next());
				sum += ind.correctSetSize;
				averageFitness += params.fitfunc.evaluate(ind);
			}
			averageFitness /= pop.size();
			
			
			int choicePoint = params.generator.nextInt(sum);
			
			sum=0;
			popit = pop.iterator();
			while (popit.hasNext())
			{
				Indiv ind = ((Indiv)popit.next());
				double deletionVote = ind.correctSetSize;
				double thisfitness = params.fitfunc.evaluate(ind);
				
				//SEE KOVACS 1999 FOR THIS BIT
				//
				if(ind.numMatches > params.ThetaDel && thisfitness < params.ThetaDelFrac*averageFitness)
				{
					deletionVote *= (averageFitness/thisfitness);
				}
				
				sum += deletionVote;
				if (sum > choicePoint)
				{
					pop.remove(ind);
					break;
				}
			}
		}
	}


	////////////////////////////////////////////////////////////////////////////////////////////
	////////////////////////////////////////////////////////////////////////////////////////////
	////////////////////////////////////////////////////////////////////////////////////////////
	
	protected void invokeGA()
	{
		//should be run only on correct set (niches)
		//
		double sumOfFitnesses=0;
		Iterator citer = correctSet.iterator();
		while (citer.hasNext())
		{
			Indiv ind = (Indiv)citer.next();

			double f = params.fitfunc.evaluate(ind);
			
			
			sumOfFitnesses += f;
			
			//UPDATE THE TIMESTAMPS TO SAY THEY ARE IN THE GA
			//
			ind.lastTimeThisWasInTheGA = ucs.UCS.currentIteration;
		}
		
		//System.out.println(sumOfFitnesses+" <--- sum Of fitnesses, cs="+cs);
		double rnd1 = params.generator.nextDouble() * sumOfFitnesses;
		double rnd2 = params.generator.nextDouble() * sumOfFitnesses;
		double sum1 = 0, sum2 = 0;
		
		int randomMommy = -1, randomDaddy = -1;
		Indiv mommy=null, daddy=null;
		
		citer = correctSet.iterator();
		while (citer.hasNext())
		{	
			Indiv ind = (Indiv)citer.next();

			double f = params.fitfunc.evaluate(ind);
			
			sum1 += f;
			sum2 += f;
			
			if (sum1 >= rnd1 && randomMommy == -1)
			{
				mommy = (Indiv)ind.clone();
				randomMommy=1;
			}
			
			if (sum2 >= rnd2 && randomDaddy == -1)
			{
				daddy = (Indiv)ind.clone();
				randomDaddy=1;
			}
		}

		Indiv[] children = mommy.crossAndMutate(daddy);
		
		
		//CHECK FOR SUBSUMPTION
		//
		for (int N=0; N<2; N++)
		{
			boolean subsumed=false;
			if (mommy.subsumes(children[N]))
			{
				pop.add( (Indiv)mommy.clone() );
				subsumed=true;
			}
			if (daddy.subsumes(children[N]))
			{
				pop.add( (Indiv)daddy.clone() );
				subsumed=true;
			}			
		
			if(!subsumed) pop.add(children[N]);
		}	
		
		while(pop.size()>params.POPMAXSIZE)
			deleteIfNecessary();
	}
	
	////////////////////////////////////////////////////////////////////////////////////////////
	////////////////////////////////////////////////////////////////////////////////////////////
	////////////////////////////////////////////////////////////////////////////////////////////

}//end class
