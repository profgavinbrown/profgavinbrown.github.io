package ucs;
import java.util.*;

/**
 * Default system predictor for UCS. As originally used by Bernardo et al.
 * @author Gavin Brown
 */
public class SystemPredictor
{
	//////////////////////////////////////////////////////////////////////////
	//////////////////////////////////////////////////////////////////////////
	//////////////////////////////////////////////////////////////////////////

	/**
	 * Gets a prediction from a matchset.  Note this does not yet support fitness sharing.
	 * @param matchSet An arraylist of individuals.
	 * @return The class predicted according to a normalized, fitness-weighted vote among the individuals.
	 */
	public int predict( ArrayList matchSet  )
	{
		double [] systemPrediction = new double[2]; //two class problem
		double normalizingConstant[] = new double[2];
		
		Iterator matchSetIterator = matchSet.iterator();
		while (matchSetIterator.hasNext())
		{
			Indiv ind = (Indiv)matchSetIterator.next();				
			systemPrediction[(int)ind.action] += ind.fitness();
			
			normalizingConstant[(int)ind.action] += ind.numerosity;
		}

		for (int c=0; c<systemPrediction.length; c++)
		{
			if(normalizingConstant[c]==0) normalizingConstant[c]=1;
			systemPrediction[c] /= (double)normalizingConstant[c];
			if (Double.isNaN(systemPrediction[c])) systemPrediction[c]=0;
		}
		
		//CHOOSE THE CLASS WITH MAXIMUM SUPPORT
		if(systemPrediction[0] > systemPrediction[1]) return 0; else return 1;
	}
	
	//////////////////////////////////////////////////////////////////////////
	//////////////////////////////////////////////////////////////////////////
	//////////////////////////////////////////////////////////////////////////

}
