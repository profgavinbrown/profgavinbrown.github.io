package demos;

import ucs.*;

/** Another UCS demo showing how to do offline learning, with train/test splits.
 *  @author Gavin Brown
 */
public class TrainTestDemo2 {

	////////////////////////////////////////////////////////////////
	////////////////////////////////////////////////////////////////
	////////////////////////////////////////////////////////////////
		
	public static void main( String [] args )
	{
		UCSconfig params = new UCSconfig();
		
		params.onlinelearning=false;
		params.setProblem("./monks3.train.csv");
		//Note: because we didn't specify a testing file, it presumes a 50:50 random split.
		
		UCS myucs = new UCS(params);
		
		//run for 20000, printing at intervals of 500
		myucs.run(20000, 500);
		
	}

	////////////////////////////////////////////////////////////////
	////////////////////////////////////////////////////////////////
	////////////////////////////////////////////////////////////////	

}//end class
