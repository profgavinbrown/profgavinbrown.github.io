package ucs;
import java.util.*;

/**
 *  System Predictor for UCSpv - same as the default predictor except
 * it does not use vote normalization.
 * @author Gavin Brown
 */
public class UCSpvSysPredictor extends SystemPredictor
{
	//////////////////////////////////////////////////////////////////////////
	//////////////////////////////////////////////////////////////////////////
	//////////////////////////////////////////////////////////////////////////

	/**
	 * UCSpv system predictor. As introduced by Brown, Kovacs, Marshall GECCO 07.
	 * @param matchSet An arraylist of individuals.
	 * @return The class predicted according to a fitness-weighted vote among the individuals.
	 */
	public int predict( ArrayList matchSet  )
	{
		double [] systemPrediction = new double[2]; //two class problem
		
		Iterator matchSetIterator = matchSet.iterator();
		while (matchSetIterator.hasNext())
		{
			Indiv indiv = (Indiv)matchSetIterator.next();				
		
			systemPrediction[(int)indiv.action] += calcCombinationWeight(indiv);
		}
		
		//SO IT DOESN'T GET NaN ERRORS
		if (Double.isNaN(systemPrediction[0])) systemPrediction[0]=0;
		if (Double.isNaN(systemPrediction[1])) systemPrediction[1]=0;
		
		//CHOOSE THE CLASS WITH MAXIMUM SUPPORT
		if(systemPrediction[0] > systemPrediction[1]) return 0; else return 1;
	}
	
	//////////////////////////////////////////////////////////////////////
	//////////////////////////////////////////////////////////////////////
	//////////////////////////////////////////////////////////////////////
	
	/**
	 * Calculates the combination weight for the UCSpv system predictor
	 * @param ind An individual to calculate for.
	 */
	private double calcCombinationWeight( Indiv indiv )
	{
		return indiv.fitness();
	}
	
	//////////////////////////////////////////////////////////////////////
	//////////////////////////////////////////////////////////////////////
	//////////////////////////////////////////////////////////////////////

}
