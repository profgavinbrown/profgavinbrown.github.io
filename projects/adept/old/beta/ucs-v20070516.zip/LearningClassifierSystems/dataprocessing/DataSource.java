package dataprocessing;

import java.io.*;
import java.util.*;

/**
 * General purpose datafile interface.  Handles all data manipulations.
 */
public class DataSource
{
	public ArrayList exampleList = null;

	public int numInputs    = -1;
	public int numOutputs   = +1;
	public int trainingSize = -1;

	public String filename="";
	
//////////////////////////////////////////////////////////////////////////////////////

	/**
	 * Constructor for a DataSource object. Opens the specified file and reads in all data, which
	 * must be in CSV (comma-separated-values) format, with one example per line.  The last value on each line is
	 * treated as the target variable.
	 * @param filename A string specifying a file from which to load some data.
	 */
	public DataSource ( String filename )
	{
		this.filename=filename;
		BufferedReader myReader = null;
		
		try
		{
			// Attempt to open the file
			//
			myReader = new BufferedReader( new FileReader( new File( filename ) ) );
		}
		catch( FileNotFoundException ex )
		{
			System.err.println( "Datafile '"+filename+"' not found." );
			System.exit(1);
		}
		
		
		//Initialise the data structure to hold our training or testing examples
		//
		exampleList = new ArrayList();
		

		try
		{
			// Loop round this while we have not reached the end of the file
			//
			
			while (myReader.ready())
			{	
				//Read one line from the file (corresponding to one Example)
				//
				String line = myReader.readLine();
			
				//Break that line up into chunks separated by commas, spaces or tabs
				//
				StringTokenizer myTokenizer = new StringTokenizer( line, ", \t" );
				
				//Initialise a data structure to hold this particular Example
				//and take away 1 since the last item is the target
				//
				if(numInputs==-1) numInputs = myTokenizer.countTokens()-1;
				
				Example thisExample = new Example( numInputs );

				//Loop through each chunk of the line we read from the file, adding to our data structure
				//
				int attrib=0;
				while (attrib < numInputs)
				{
					Double val = new Double( myTokenizer.nextToken() );
					
					thisExample.inputs[attrib] = val.doubleValue();
					Example.inputAlphabet[attrib].add( val );
					
					attrib++;
				}

				//Now read the target value
				//
				thisExample.target = Double.parseDouble( myTokenizer.nextToken() );

				//Add this Example to our list of examples
				//
				exampleList.add( thisExample );
			}
		}
		catch (IOException ioe)
		{
			System.err.println( "IO Exception when reading datafile '"+filename+"'." );
			System.exit(1);
		}
		
		
		//Now go through the example list
		int maxclass=0, minclass=100;
		for (int i=0; i<exampleList.size(); i++)
		{
			Example e = (Example)exampleList.get(i);
			if (e.target>maxclass) maxclass=(int)e.target;
			if (e.target<minclass) minclass=(int)e.target;
		}
		
		
		int C = (maxclass-minclass)+1;
		numOutputs = C;
		
		for (int i=0; i<exampleList.size(); i++)
		{
			Example e = (Example)exampleList.get(i);
			e.target = e.target - minclass;
		}
		
		System.out.println("Data loaded: "+filename);
	}
	
//////////////////////////////////////////////////////////////////////////////////////
	
	/**
	 * Returns the total number of Examples available in this DataSource.
	 * @return The number of Examples.
	 */
	public int numExamples()
	{
		return exampleList.size();
	}
	
//////////////////////////////////////////////////////////////////////////////////////

	/**
	 * Returns an ArrayList of <b>Example</b> objects, containing all data in this source.
	 * @return The number of Examples.
	 */
	public ArrayList getData()
	{
		return exampleList;
	}

//////////////////////////////////////////////////////////////////////////////////////

	/**
	 * Randomly shuffles this DataSource.  After a call to this method, all data in this source will be in random order.
     * @return Nothing.
	 */
	public void shuffle()
	{
		ArrayList shuffled = new ArrayList();
		Random gen = new Random();
		
		//System.out.println("before: "+exampleList.size());
		
		while (exampleList.size() > 0)
		{
			int eg = gen.nextInt(exampleList.size());
			shuffled.add( exampleList.get(eg) );
			exampleList.remove(eg);
		}
		
		//System.out.println("after: "+shuffled.size());

		exampleList = shuffled;
	}
	
//////////////////////////////////////////////////////////////////////////////////////

	/**
	 * Returns an ArrayList of Example objects to use as training data.  If trainingSize is not set, this method 
	 * returns the first 50% of the data.
	 * @return An ArrayList of Examples.
	 */
	public ArrayList getTrainingData()
	{
		if (trainingSize == -1) trainingSize = exampleList.size()/2;
		
		ArrayList training = new ArrayList();
		
		for (int i=0; i<trainingSize; i++)
			training.add( exampleList.get(i) );
			
		return training;
	}

//////////////////////////////////////////////////////////////////////////////////////
	
	/**
	 * Returns an ArrayList of Example objects to use as testing data.  If trainingSize is not set, this method 
	 * returns the last 50% of the data.
	 * @return An ArrayList of Examples.
	 */
	public ArrayList getTestingData()
	{
		if (trainingSize == -1) trainingSize = exampleList.size()/2;
		
		ArrayList testing = new ArrayList();
		
		for (int i=trainingSize; i<exampleList.size(); i++)
			testing.add( exampleList.get(i) );
			
		return testing;
	}

//////////////////////////////////////////////////////////////////////////////////////

	/**
	 * Prints out every Example in this DataSource.
	 */
	public void printData()
	{
		for (int whichExample=0; whichExample<numExamples(); whichExample++)
		{
			//Retrieve the Example at index number 'whichExample'
			//
			Example thisExample = (Example)exampleList.get(whichExample);
			
			//Print it
			//
			thisExample.print();
		}
	}


//////////////////////////////////////////////////////////////////////////////////////	
	
	/**
	 * Adds noise to the target of the supplied ArrayList with probability prob.
	 * @param prob The probability of class noise being added to each Example.
	 * @param data An ArrayList of Examples to apply the noise to.
	 */
	public void addTargetNoise(double prob, ArrayList data)
	{
		for (int whichExample=0; whichExample<data.size(); whichExample++)
		{
			//Retrieve the Example at index number 'whichExample'
			//
			Example ex = (Example)data.get(whichExample);
			
			if(Math.random() < prob)
			{
				//corrupt the data
				//
				if(ex.target==1) ex.target=0; else ex.target=1;
			}
		}
	}


//////////////////////////////////////////////////////////////////////////////////////	
	
}

